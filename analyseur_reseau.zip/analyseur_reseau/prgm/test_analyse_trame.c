#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "analyse_trame.h"
#include "lecture_trame.h"
#include <string.h>


/* Fichier test analyse trame */

int main(int argc, char const *argv[])
{   
    printf("on entre dans le main\n");
    if(argc != 2)
    {
        fprintf(stderr, "Erreur lors de l'analyse du fichier\n");
        return EXIT_FAILURE;
    }

    char *fic = (char *)argv[1];

    Trace *trace=get_trace(fic);
    printf("on a get trace\n");
    if(trace == NULL)
    {
        // Mauvais format pour le fichier
        return 2;
    }
    
    printf("========= ANALYSE EN COURS ======================\n");
    
    List_Printable* lp=trace_brut_to_str( trace);
    printf("on a lp\n");

    print_list_cell_printable(lp);
    
    FILE* fichier = NULL;
    fichier = fopen("printf.txt", "w");
    generate_file(fichier,lp);
    printf("on a generate file\n");
    free_list_Printable(lp);
    free_trace(trace);

    return 0;
}
